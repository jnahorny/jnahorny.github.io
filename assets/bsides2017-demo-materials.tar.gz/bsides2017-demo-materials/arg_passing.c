#include <stdio.h>

int sum (int a, int b, int c, int d, int e, int f, int g) {
  return a + b + c + d + e + f + g;
}

int main() {
  sum(1, 2, 3, 4, 5, 6, 7);
  return 0;
}
