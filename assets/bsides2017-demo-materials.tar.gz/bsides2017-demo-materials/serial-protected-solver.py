
with open("enc_flag.txt") as f:
    enc = f.readlines()

enc = [a.strip() for a in enc]

dec = [chr(int(a, 16) ^ 1) for a in enc]
print ''.join(dec)
