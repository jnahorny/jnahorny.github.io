#include <stdio.h>


int weird_func(int a, int b) {
  int x = a * 2;
  int y = b * 3;
  int foo = x + y;
  return foo ^ (x * y);
}

int main() {
  printf("Result: %d\n", weird_func(1,3));
}
