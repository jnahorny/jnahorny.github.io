#include <stdio.h>
#include <string.h>

void reveal() {
  printf("Activation successful! You may now use our product\n");
}

int password_check(char *password) {

  char secret[] = {103, 109, 96, 102, 122, 67, 82, 104, 101, 100, 114, 51, 49, 48, 54, 124};
  int secret_len = sizeof(secret)/sizeof(char);

  if (strnlen(password, 20) == secret_len) {
    for (int i = 0; i < secret_len; i++) {
      if ((password[i] ^ 1) != secret[i]) {
	return 0;
      }
    }
    // OK
    return 1;

  }
  return 0;
}


int main(int argc, char **argv) {

  if (argc < 2) {
    return 26;
  }

  char *p = argv[1];

  if (! password_check(p)) {
    printf("WRONG!!!\n");
    return 42;
  }
  reveal();
  return 0;
}
