import r2pipe

r2p = r2pipe.open()
r2p.cmd('aaa')
r2p.cmd('s 0x00400544')

enc = []
for b in r2p.cmdj('aoj 16'):
    by = b['opcode'].split()[-1]
    enc.append(by)
    print('[+] Byte ' + by)

dec = [chr(int(b,16) ^ 1) for b in enc]
print('[+] Solution: ' +''.join(dec))

#r2p.cmd('q')
