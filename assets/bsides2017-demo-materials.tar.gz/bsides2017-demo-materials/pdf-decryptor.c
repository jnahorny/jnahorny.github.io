#include <stdio.h>
#include <string.h>

void reveal() {
  printf("The secret is: CEBULA\n");
}

int password_check(char *password) {
  char *secret = "burak";

  if (strnlen(password, 20) == 5) {
    if (strncmp(password, secret, 5) == 0) {
      return 1;
    }
  }
  return 0;
}


int main(int argc, char **argv) {

  if (argc < 2) {
    return 26;
  }

  char *p = argv[1];

  if (password_check(p)) {
    printf("SUCCESS!\n");
    reveal();
    return 0;
  }
  printf("WRONG!!!\n");
  return 42;
  
}
