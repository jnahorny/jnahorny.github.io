#include <stdio.h>

int main() {
  printf("Hello\n");
  printf("Can you find me?  ¯\\_(ツ)_/¯\n");
}
